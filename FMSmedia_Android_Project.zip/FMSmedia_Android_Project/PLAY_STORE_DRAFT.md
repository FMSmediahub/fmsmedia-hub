# Google Play listing draft

**App name:** FMSmedia Hub  
**Short description (draft):** Explore FMSmedia creative services, portfolio and start your next project.  
**Category suggestion:** Business (final category should match the actual app and Play Console options).  
**Developer:** FMSmedia  

**Full description (draft):**
FMSmedia Hub brings our creative media services and project journey together in one mobile-friendly experience. Explore video and film production, photography, graphic design and branding, social content, web and digital services, and entertainment projects. View portfolio categories and prepare a project request with your contact details and brief. FMSmedia Hub is the starting point for our growing creative ecosystem.

**Current limitations to disclose during testing:** The portfolio is sample-category content; project requests are prepared locally for copying and are not submitted to a server or automatically delivered to FMSmedia. Some planned app-suite items are placeholders.
