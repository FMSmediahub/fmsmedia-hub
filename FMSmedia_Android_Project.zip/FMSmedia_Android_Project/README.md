# FMSmedia Hub — Android packaging starter

This folder contains the mobile-friendly Hub prototype, PWA files, and Capacitor configuration for a future Android package.

## What's ready
- Web app source in `www/index.html`
- Installable PWA metadata (`manifest.webmanifest`)
- Basic offline cache (`sw.js`)
- Black/gold app icons in `www/icons/`
- Capacitor app ID: `com.fmsmedia.hub`

## Important: this is not an APK/AAB yet
Android build output has not been generated. The Android native project is created by Capacitor on a computer with Node.js and Android Studio/Android SDK installed. Publishing also requires a Google Play Console developer account, app signing, store listing, testing and review.

## Build on a computer (Windows/macOS/Linux)
1. Install Node.js LTS and Android Studio (including Android SDK tools).
2. Unzip this project folder.
3. Open a terminal inside the folder and run:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. In Android Studio, allow Gradle/SDK setup to finish, then test on an Android phone or emulator.
5. For a test APK: Android Studio **Build > Build Bundle(s) / APK(s) > Build APK(s)** (menu wording may vary). Install only the APK you built and verify all screens, navigation, request-form behavior and offline startup.
6. For Google Play: generate a signed Android App Bundle (AAB) using Android Studio **Build > Generate Signed Bundle / APK > Android App Bundle**. Keep signing keys secure and never share them.

## Phone-only build option (GitHub Actions)
This project includes `.github/workflows/build-android-apk.yml` to make a debug APK in GitHub's cloud CI after you upload the project to a GitHub repository.
1. On your Android phone, sign in/create a GitHub account and create a new repository named `fmsmedia-hub`.
2. Upload the contents of this project ZIP to the repository (make sure the `.github/workflows/build-android-apk.yml` file is included; if the GitHub mobile upload flow hides dot-folders, use GitHub's web view in Desktop mode or ask for help with that step).
3. Open the repository's **Actions** tab, choose **Build FMSmedia Hub Android APK**, and tap **Run workflow** if it has not started automatically after pushing to `main`.
4. Wait for the workflow to finish successfully. Open the completed run and download its **FMSmedia-Hub-debug-APK** artifact. GitHub packages that artifact as a ZIP; download and extract it to get `app-debug.apk`.
5. On your phone, tap the APK to install. Android may ask you to allow installation from that source; only enable this for the trusted file you built, then turn it off again afterward.

This workflow creates a **debug APK for testing**, not a Play Store release. A signed release AAB and Google Play publishing still require release signing and Play Console steps.

## Before publishing
- Replace the sample portfolio tiles with real work and approved images.
- Add a real contact/WhatsApp destination and server-side form submission (the current form only prepares/copies a message; it does not send or save requests).
- Add privacy policy and disclose data practices accurately.
- Test links, accessibility, different screen sizes, offline behavior, and app back-button behavior.
- Prepare Play Store screenshots, feature graphic, description, content rating and app access details.
- Confirm Google Play's current target API, testing, verification, and account requirements at Play Console.
